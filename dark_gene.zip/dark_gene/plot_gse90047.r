setwd("C:/Users/ADMIN/Desktop/cell_analysis2/GSE90047_function_analysis")
options(stringsAsFactors = F)
library(sscClust)
library(dplyr)
library(Cairo)
library(reshape2)
library(plotly)
library(ggpubr)
library(scatterplot3d)
library(rayshader)


entropymatrix<-read.csv(file = "GSE90047_signal_gene_entropy.csv",header = T)


gene_meta<-read.csv(file = "mart_export.csv",header = T)
entropymatrix<-entropymatrix %>% distinct(Gene_name,.keep_all = T)
signaluniquesymbol<-as.data.frame(entropymatrix$Gene_name)
names(signaluniquesymbol)<-'Gene_name'
signalgene_metadata<-merge(signaluniquesymbol,gene_meta,by = 'Gene_name')
signalgene_metadata<-signalgene_metadata %>% distinct(Gene_name,.keep_all = T)
signalgene_metadata<-signalgene_metadata %>% arrange(desc(Gene_name))
signaluniquesymbol<-as.data.frame(signalgene_metadata$Gene_name)
names(signaluniquesymbol)<-'Gene_name'
row.names(signalgene_metadata)<-signalgene_metadata$Gene_name
signalgene_metadata<-signalgene_metadata[,-1]
entropymatrix<-merge(signaluniquesymbol,entropymatrix,by= 'Gene_name')
entropymatrix<-entropymatrix %>% arrange(desc(Gene_name))
row.names(entropymatrix)<-entropymatrix$Gene_name


#genesymbol<-as.data.frame(gene_meta$Gene_stable_ID)
#names(genesymbol)<-"Gene_stable_ID"
geneexpr<-read.csv("GSE90047_expression_matrix.CSV",sep = ",")
geneexpr<-geneexpr %>% distinct(Gene_name,.keep_all = T)
row.names(geneexpr)<-geneexpr$Gene_name

#signalgene_expr<-merge(genesymbol,geneexpr,by = 'Gene_stable_ID')
signalgene_expr<-merge(gene_meta,geneexpr,by = 'Gene_name')
signalgene_expr<-signalgene_expr[,c(-1)]
signalgene_expr<-signalgene_expr %>% arrange(desc(gene_short_name))
row.names(signalgene_expr)<-signalgene_expr$gene_short_name
signalgene_expr<-signalgene_expr[,c(-1)]
signalgene_expr<-as.data.frame(t(signalgene_expr))



expr_time<-c(rep('E10.5',54),rep('E11.5',70),rep('E12.5',41),
             rep('E13.5',65),rep('E14.5',70),rep('E15.5',77),rep('E17.5',70))
expr_time<-factor(expr_time,
                  levels = c("E10.5","E11.5","E12.5","E13.5","E14.5","E15.5","E17.5"))
expr_time

signalgene_expr[,'Time']<-expr_time
signalgene_expr$Time


entropymatrix<-entropymatrix[,-1]
entropymatrix<-as.data.frame(t(entropymatrix))
entropymatrix[,'Time']<-expr_time
entropymatrix$Time

rownames(signalgene_expr)<-NULL
rownames(entropymatrix)<-NULL



signalgene_expr=subset(signalgene_expr,select=-Time)
signalgene_expr=log(signalgene_expr+1)
signalgene_expr[,'Time']<-expr_time
setwd("C:/Users/ADMIN/Desktop/90047_re")
#pdf("every_gene_dark_by_time.pdf")
for (i in 1:182) {
  str1=names(entropymatrix)[i]
  p1<-ggplot(data = signalgene_expr,aes_string(x = 'Time',y = as.character(names(signalgene_expr)[i]),group = 1))
  
  p1<-p1+ylab("Gene expression")
  
  p1<-p1+
    theme(title = element_text(size = 16,face = 'bold'))+
    theme(plot.title = element_text(hjust = 0.5))
  
  p1<-p1 + geom_jitter(aes(color = Time), size = 3)+
    stat_summary(fun.y = "mean", size = 2, geom = "line")
  
  p1<-p1+theme(legend.position="none",
               panel.background = element_blank(),
               panel.border = element_blank(),
               panel.grid.major = element_blank(),
               panel.grid.minor = element_blank(),
               axis.line.y = element_line(colour = "black"))
  p1<-p1 + theme(axis.text.x = element_text(size = 16, color = "black", face = "bold"))
  p1<-p1 + theme(axis.text.y = element_text(size =16, color = "black", face = "bold"))
  
  
  p2<-ggplot(data = entropymatrix,aes_string(x ='Time', y=names(entropymatrix)[i],group = 1))
  
  p2<-p2+labs(title = names(entropymatrix)[i])+
    theme(axis.title = element_text(size = 16,face = 'bold'))+
    theme(plot.title = element_text(hjust = 0.5))+
    theme(title = element_text(size =16,face = "bold.italic"))
  
  p2<-p2+ylab("Local SGE")
  
  p2<-p2 + geom_jitter(aes(color = Time), size = 3)+
    stat_summary(fun.y = "mean", size = 2, geom = "line")
  
  p2<-p2+theme(legend.position="none",
               panel.background = element_blank(),
               panel.border = element_blank(),
               panel.grid.major = element_blank(),
               panel.grid.minor = element_blank(),
               axis.line.y = element_line(colour = "black"))
  
  p2<-p2 + theme(axis.text.x = element_text(size = 16, color = "black", face = "bold"))
  p2<-p2 + theme(axis.text.y = element_text(size = 16, color = "black", face = "bold"))
  
  p<-ggarrange(p2,p1,heights=c(1/2, 1/2),ncol = 1, nrow = 2,common.legend = FALSE,align = "v")
  
  ggsave(p,filename = paste(str1,".tiff"),width =6,height = 6)
  
  while (!is.null(dev.list()))  dev.off()
  
  
  print(p)
}

dev.off()
rm(list = ls())